package com.likelyspeaker.app

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaProjection
import android.media.projection.MediaProjectionManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val port = 45821
    private val running = AtomicBoolean(false)
    private var server: ServerSocket? = null
    private var socket: Socket? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private lateinit var status: TextView
    private lateinit var ipInput: EditText
    private lateinit var startReceiver: Button
    private lateinit var startSender: Button
    private lateinit var stopButton: Button
    private lateinit var projectionManager: MediaProjectionManager
    private var projection: MediaProjection? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        buildUi()
    }

    private fun buildUi() {
        val bg = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF11152A.toInt(), 0xFF24204A.toInt(), 0xFF11152A.toInt())
        )
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            background = bg
        }
        val title = TextView(this).apply {
            text = "LIKELY  SPEAKER"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your second phone. Your wireless sound system."
            textSize = 13f
            setTextColor(0xFFBFC5E8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 26)
        }
        status = TextView(this).apply {
            text = "●  NOT CONNECTED"
            textSize = 14f
            setTextColor(0xFFFFC857.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 16, 12, 16)
            background = rounded(0x332FFFFFF)
        }
        val receiverCard = card()
        receiverCard.addView(label("PHONE 2  •  RECEIVER"))
        receiverCard.addView(label("Play incoming audio through this phone's speaker."))
        startReceiver = button("Start as Speaker")
        receiverCard.addView(startReceiver)
        val senderCard = card()
        senderCard.addView(label("PHONE 1  •  SENDER"))
        senderCard.addView(label("Capture supported app audio and send it over Wi-Fi."))
        ipInput = EditText(this).apply {
            hint = "Receiver phone IP address"
            setSingleLine(true)
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9EA6C9.toInt())
            setPadding(14, 12, 14, 12)
            background = rounded(0xFF303653.toInt())
        }
        senderCard.addView(ipInput)
        startSender = button("Connect & Share Audio")
        senderCard.addView(startSender)
        stopButton = button("Stop")
        stopButton.isEnabled = false
        val foot = TextView(this).apply {
            text = "Both phones must be on the same Wi-Fi network or one phone's hotspot. Android 10+ required."
            textSize = 12f
            setTextColor(0xFF9EA6C9.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 22, 8, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(receiverCard, paramsTop(20))
        layout.addView(senderCard, paramsTop(14))
        layout.addView(stopButton, paramsTop(14))
        layout.addView(foot)
        setContentView(ScrollView(this).apply { addView(layout) })

        startReceiver.setOnClickListener { beginReceiver() }
        startSender.setOnClickListener { requestCapturePermission() }
        stopButton.setOnClickListener { stopAll("Stopped") }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 16, 16, 16)
        background = rounded(0xFF1D2340.toInt())
    }
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(0xFFE4E7FF.toInt()); setPadding(0, 3, 0, 10)
    }
    private fun button(s: String) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 15f
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(0xFF735BFF.toInt())
        setPadding(8, 8, 8, 8)
    }
    private fun rounded(color: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = 22f
    }
    private fun paramsTop(top: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = top }

    private fun beginReceiver() {
        if (running.get()) return
        running.set(true)
        startReceiver.isEnabled = false
        stopButton.isEnabled = true
        val ip = localIpAddress()
        status.text = "●  WAITING FOR SENDER\n$ip : $port"
        thread {
            try {
                server = ServerSocket(port)
                val incoming = server!!.accept()
                socket = incoming
                runOnUiThread { status.text = "●  CONNECTED — PLAYING AUDIO" }
                receiveAudio(incoming)
            } catch (e: Exception) {
                if (running.get()) runOnUiThread { status.text = "Connection error: ${e.message}" }
            } finally {
                stopAll("Receiver stopped")
            }
        }
    }

    private fun requestCapturePermission() {
        val ip = ipInput.text.toString().trim()
        if (ip.isBlank()) {
            Toast.makeText(this, "Enter the receiver phone's IP address first.", Toast.LENGTH_LONG).show()
            return
        }
        pendingIp = ip
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    private var pendingIp = ""
    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Audio capture permission was not granted.", Toast.LENGTH_LONG).show()
            return
        }
        projection = projectionManager.getMediaProjection(resultCode, data)
        beginSender(pendingIp, projection!!)
    }

    private fun beginSender(ip: String, mediaProjection: MediaProjection) {
        if (running.get()) return
        running.set(true)
        startSender.isEnabled = false
        stopButton.isEnabled = true
        status.text = "●  CONNECTING TO $ip"
        thread {
            try {
                val s = Socket(ip, port)
                socket = s
                val format = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build()
                val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(android.media.AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                audioRecord = AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(maxOf(min, 8192))
                    .setAudioPlaybackCaptureConfig(config)
                    .build()
                audioRecord!!.startRecording()
                runOnUiThread { status.text = "●  SHARING AUDIO OVER WI-FI" }
                val out = BufferedOutputStream(s.getOutputStream())
                val buffer = ByteArray(4096)
                while (running.get()) {
                    val count = audioRecord!!.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        out.write(buffer, 0, count)
                        out.flush()
                    }
                }
            } catch (e: Exception) {
                if (running.get()) runOnUiThread { status.text = "Sender error: ${e.message}" }
            } finally {
                stopAll("Sender stopped")
            }
        }
    }

    private fun receiveAudio(s: Socket) {
        val input = BufferedInputStream(s.getInputStream())
        val min = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack!!.play()
        val buffer = ByteArray(4096)
        while (running.get()) {
            val n = input.read(buffer)
            if (n <= 0) break
            audioTrack!!.write(buffer, 0, n)
        }
    }

    private fun localIpAddress(): String {
        return try {
            Collections.list(NetworkInterface.getNetworkInterfaces()).asSequence()
                .flatMap { Collections.list(it.inetAddresses).asSequence() }
                .first { it is Inet4Address && !it.isLoopbackAddress }
                .hostAddress ?: "Find IP in Wi-Fi settings"
        } catch (_: Exception) { "Find IP in Wi-Fi settings" }
    }

    private fun stopAll(message: String) {
        running.set(false)
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        try { server?.close() } catch (_: Exception) {}
        server = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        runOnUiThread {
            status.text = "●  $message"
            startReceiver.isEnabled = true
            startSender.isEnabled = true
            stopButton.isEnabled = false
        }
    }

    override fun onDestroy() {
        stopAll("Disconnected")
        super.onDestroy()
    }

    companion object { private const val REQUEST_CAPTURE = 4102 }
}
