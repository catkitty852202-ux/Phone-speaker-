plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.likelyspeaker.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.likelyspeaker.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
