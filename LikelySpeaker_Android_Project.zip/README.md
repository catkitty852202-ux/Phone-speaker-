# Likely Speaker — Android prototype

This is the first native Android prototype for sending supported app playback audio from one Android phone to another over the same Wi-Fi network / hotspot.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK on both Android phones (Android 10 / API 29 or newer).

## First test
1. Connect both phones to the same Wi-Fi, or connect the sender to the receiver phone's hotspot.
2. On the receiver phone, tap **Start as Speaker**. It shows its local IP and port.
3. On the sender phone, enter that IP and tap **Connect & Share Audio**.
4. Approve Android's system audio-capture prompt.
5. Play media from an app that permits playback capture.

## Important prototype limitations
- This first build uses Wi-Fi TCP and manual IP entry. Bluetooth, automatic discovery, background foreground-service support, adaptive buffering, and polished reconnect behavior are not implemented yet.
- Android's playback-capture policy is enforced by each source app. Some apps (including apps that mark audio as protected) cannot be captured.
- The app is a prototype and has not been compiled or tested on physical devices in this environment. Build and test it in Android Studio before relying on it.
- Keep both devices on a trusted private network. This prototype does not encrypt the audio stream or authenticate peers.
